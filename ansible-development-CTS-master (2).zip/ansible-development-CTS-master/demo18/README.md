# ansible-development-CTS

# SETTING UP AWS INFR.
- Three instance in avaliablity zonea.
- Deploying Apache Server
- Deploying Custom Index & Info Web Pages. 
