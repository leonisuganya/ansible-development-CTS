Introduction to Anisble Vault & WordPress LAMP Stack Deployment with Rolling Updates. 
