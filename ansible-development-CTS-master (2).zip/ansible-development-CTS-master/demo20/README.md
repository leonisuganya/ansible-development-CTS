# ansible-development-CTS

# SETTING UP GCP INFR.
- Two instance in avaliablity zone A.
- Two instance in avaliablity zone B.
- Setting up a GCP LoadBalancer in front of all Four instances 
- Deploying Apache Server
- Deploying Custom Index & Info Web Pages. 
- Clean up the entire Infa. 
