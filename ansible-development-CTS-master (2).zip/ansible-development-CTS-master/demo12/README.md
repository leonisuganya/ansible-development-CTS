Multiple Ansible Role Demo. 

- server-common
- webserver
- dbserver

Introduction to TAG's & Limit Operation.
