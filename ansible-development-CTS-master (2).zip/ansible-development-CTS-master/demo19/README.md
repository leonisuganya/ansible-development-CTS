# ansible-development-CTS

# SETTING UP GCP INFR.
- Two instance in avaliablity zone A.
- Two instance in avaliablity zone B.
- Deploying Apache Server
- Deploying Custom Index & Info Web Pages. 
