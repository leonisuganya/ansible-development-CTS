Introduction to Anisble Vault & WordPress LAMP Stack Deployment with Rolling Updates. 

Update 1: Introduction Local Actions
Update 2: Introduction Delegation
